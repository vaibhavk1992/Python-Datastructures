import math

def merge(arr,base,mid,last):
  larr=[]
  rarr=[]
  print ("bas emid and last",base,mid ,last)
  for i in range(base,mid+1):
    print(arr[i])
    larr.append(arr[i])
  for j in range(mid+1,last+1):
    print(arr[j])
    rarr.append(arr[j])
  print ("larr",larr)
  print ("rarr",rarr)
  i=0
  j=0
  k=base
  
  while(i<len(larr) and j<len(rarr)):
    if larr[i]<rarr[j]:
      arr[k]=larr[i]
      i=i+1
    else:
      arr[k]=rarr[j]
      j=j+1
      
    k=k+1
  
  while (i < mid - base + 1):
        print ("2 while")
        arr[k] = larr[i]
        i=i+1
        k=k+1
    
 
  while (j < last-mid):
        print ("3 while",j)
        arr[k] = rarr[j]
        j=j+1
        k=k+1
  
  print (arr)
  
def mergesort(arr,base,last):
  if base==last:
    return
  else:
    mid=(base+last)/2
    mid=math.floor(mid)
    mergesort(arr,base,mid)
    mergesort(arr,mid+1,last)
    merge(arr,base,mid,last)

arr=[6,5,12,10,9,1]
print (mergesort(arr,0,5))