def check_duplicates(arr,k):
  d=set()
  for i in range(k+1):
    if arr[i] in d:
      return False
    else:
      d.add(arr[i])
  return True    
print (check_duplicates([1, 2, 3, 4, 1, 2, 3, 4],3))